import {Request, Response, Router} from "express";
import {CreateUserType} from "../user/types/create-user.type";
import {Users} from "../user/users.model";


const router = Router();

router.get("/register", async (req: Request, res: Response) => {
    return res.render('auth/register')
});
router.post("/register", async (req: Request, res:Response) => {
    const user: Users = await Users.create({...req.body});
    return res.status(201).json(user);
});

router.get("/login", async (req: Request, res: Response) => {
    return res.render('auth/login')
});


export default router;