import {Request, Response, Router} from "express";
import {Users} from "./users.model"
import {findAll, findById, updateUser, deleteUser} from "./users.service";
import {GetUserType} from "./types/get-user.type";
import {CreateUserType} from "./types/create-user.type";
import {UpdateUserBodyType, UpdateUserType} from "./types/update-user.type";

const router = Router();

router.get('/', async (req: Request, res: Response): Promise<void> => {
    const allUsers: Users[] = await findAll();
    return res.render('index', {users: allUsers});
})
router.get("/:id/", async (req: Request<GetUserType>, res: Response): Promise<void> => {
    const {id} = req.params;
    const user: Users | null = await findById(id);
    return res.status(user ? 200 : 404).render('users/detail', {user});
})
router.post("/", async (req: Request, res: Response): Promise<Response<CreateUserType>> => {
    const user: Users = await Users.create({...req.body});
    return res.status(201).json(user);
})
router.put("/:id/", async (req: Request<UpdateUserType, unknown, UpdateUserBodyType>, res: Response): Promise<Response> => {
    const {id} = req.params;
    const updatedUser = updateUser(id, req.body)
    return res.status(200).json(updatedUser);
})
router.delete("/:id", async (req: Request<{ id: number }>, res: Response): Promise<Response> => {
    const {id} = req.params;
    return res.json(deleteUser);
})
export default router;