export declare type GetUserType = {
    id: number
}