import {IUser} from "../users.model";

export declare type CreateUserType = IUser;