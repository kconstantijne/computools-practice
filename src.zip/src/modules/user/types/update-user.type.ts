export declare type UpdateUserType = {
    id: number;
}

export declare type UpdateUserBodyType = {
    firstname: string;
    lastname: string;
}