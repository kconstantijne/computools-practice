import {Table, Model, Column, DataType} from "sequelize-typescript";

export interface IUser {
    email: string;
    password: string;
}

@Table({
    timestamps: false,
    tableName: "users",
})
export class Users extends Model {
    @Column({
        type: DataType.STRING,
        allowNull: false,
    })
    firstname: string;

    @Column({
        type: DataType.STRING,
        allowNull: false,
    })
    lastname: string;

    @Column({
        type: DataType.STRING,
        allowNull: false,
    })
    email: string;

    @Column({
        type: DataType.INTEGER,
        allowNull: false,
    })
    password: string;

}