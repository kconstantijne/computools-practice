import {Users} from "./users.model";
import {UpdateUserBodyType} from "./types/update-user.type";

export const findAll = async (): Promise<Users[]> => Users.findAll();

export const findById = async (id: number): Promise<Users | null> => Users.findByPk(id)

export const updateUser = async (id: number, params: UpdateUserBodyType): Promise<Users | string> => {
    // Update user functionality
    const user = await Users.findByPk(id)

    if (!user) {
        return "User not found"
    }
    console.log(params)
    await user.update(params)
    return user.save();

}

export const deleteUser = async (id: number): Promise<Users | string> => {
    const user = Users.findByPk(id)
    if (user) {
        const deletedUser: Users | null = await Users.findByPk(id);
        await Users.destroy({where: {id}});
        return deletedUser
    }
    return "User not found"
}