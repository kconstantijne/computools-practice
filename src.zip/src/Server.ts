import routes from "./routes";
import bootstrap from "./bootstrap";
import * as path from "path";

const app = bootstrap();
const port = process.env.APP_PORT; // default port to listen

// define a route handler for the default home page
app.use(routes);

// start the express server
app.listen(port, () => {
    // tslint:disable-next-line:no-console
    console.log(`server started at http://localhost:${port}/users`);
});