import {Router} from "express";

const router = Router();


router.get('/', (req, res) => {
    return res.render('index', { title: 'App status', message: 'Online'});
})

export default router;