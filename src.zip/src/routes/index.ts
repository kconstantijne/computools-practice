import {Router} from "express";

import echo from "./echo"
import users from '../modules/user/users.routes';
import auth from '../modules/auth/auth.routes'

const router = Router();

router.use('/echo', echo);
router.use('/users', users);
router.use('/auth', auth);

export default router;