import {Router} from "express";
import {Users} from "../modules/user/users.model";

const router = Router();

router.get('/', async (req, res) => {
    const allUsers: Users[] = await Users.findAll();
    return res.render('index', {title: 'Test', message: 'test'});
})

export default router;