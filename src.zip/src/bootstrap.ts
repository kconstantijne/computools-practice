import path from "path";
import express from "express";
import {config} from 'dotenv'
import {Server} from 'socket.io';
import {createServer} from "http";
import connection from "./database/connection";


const initialiseApplication = (() => {
    config();
    connection.sync();
    const app = express();
    app.use(express.json())
    app.set("views", path.join(__dirname, "/views"));
    app.set('view engine', 'pug');

    return app;
})

export default initialiseApplication;