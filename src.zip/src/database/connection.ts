import { Sequelize } from "sequelize-typescript";

import { Users } from "../modules/user/users.model";

const connection = new Sequelize({
    dialect: "postgres",
    host: "localhost",
    username: "postgres",
    password: "passwd",
    database: "dbpractice",
    logging: false,
    models: [Users],
});

export default connection;